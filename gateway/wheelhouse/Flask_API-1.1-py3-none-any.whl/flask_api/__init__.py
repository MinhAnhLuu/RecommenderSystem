from flask_api.app import FlaskAPI

__version__ = '1.1'
